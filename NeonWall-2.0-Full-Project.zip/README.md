# NeonWall 2.0 — Android project

NeonWall is a Kotlin/Jetpack Compose live-wallpaper app prototype intended to build with GitHub Actions on `ubuntu-latest` and JDK 17. The repository root is the Gradle project root; **do not put the project inside another ZIP**.

## Build

```bash
./gradlew assembleDebug --no-daemon
```

Windows:

```bat
gradlew.bat assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The included GitHub Actions workflow builds this exact root project on pushes to `main` and manual dispatch, uploads `neonwall-apk`, and uploads `neonwall-build-log` even when compilation fails.

## Toolchain / dependencies

- JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21
- compileSdk / targetSdk 35; minSdk 29
- Compose BOM 2024.12.01, Material 3, AndroidX Core 1.15.0, Activity Compose 1.9.3, Lifecycle 2.8.7
- Glance AppWidget 1.1.1, WorkManager 2.10.0, coroutines 1.9.0
- Repositories: `google()` and `mavenCentral()` (Gradle Plugin Portal only for plugin resolution). No additional app dependency was added for the Studio/shortcut/project archive tools; they use Android APIs and the Java standard library.

## Included

- Uzbek-first Compose app with library, Photo Live, wallpaper settings, widgets, Studio and power/performance sections.
- 20 procedural scene entries and 50 original generated static wallpaper assets in `app/src/main/assets/wallpapers/`.
- `catalog.json` seed catalogue and `LICENSES.txt` for bundled artwork.
- Wallpaper service with particle field, parallax sensor support, touch ripples, day/night palette, audio-reactive drawing, and FPS/battery/thermal policy.
- Photo Live: gallery photo, Ken Burns, particle overlay, vignette, warm/cool/mono filters. The video/GIF chooser is currently a UI placeholder; actual Media3/MediaPlayer playback is not implemented yet.
- Charging screen with animated rings, battery percentage/temperature, double-tap dismiss, optional tone, and a power-connected notification. Android/HyperOS may suppress background full-screen launches; notification tap is the safe fallback. This build does not claim unrestricted auto-launch on every Xiaomi ROM.
- Screen-visible reveal animation in the wallpaper engine and sensor-based parallax.
- Three Glance widgets, music notification access integration, weather/system readers and performance settings.
- Studio layer model with add/remove/duplicate/reorder/lock, position/size/opacity controls, local project save, and `.neonpack` ZIP export/import (`project.json` + optional shortcut image).
- Ten launcher activity-alias names/icons and a pinned home-screen shortcut maker. Android launchers may delay refreshing the icon; a pinned shortcut is not a replacement for the installed app icon.

## Important current limitations

This is a substantial starter project, not a claim that every item from the full product brief is production-complete. In particular:

- Scene cards and static assets are bundled, but not every named scene yet has a unique dedicated renderer; some scenes share the common procedural engine.
- Photo depth segmentation, Media3 video playback, AGSL distortion, complete per-layer runtime rendering/animation/touch-gyro actions, automatic scheduled wallpaper rotation, online remote catalog synchronization, and five fully configurable widget layouts are not yet complete.
- Charging current/voltage/wattage/time-to-full, custom audio-file selection, quiet-hours scheduling, foreground-service auto-launch, and a guided Xiaomi autostart/battery-permission flow remain follow-up work.
- A pinned shortcut is created only after launcher confirmation. Arbitrary image replacement of the installed app icon is not supported by Android; aliases provide only the ten bundled variants.

Please run the GitHub Actions build before installing. This environment cannot download the Gradle distribution, so a full local Gradle compile was not possible here. If CI fails, share the `neonwall-build-log` artifact and fix the first actual Gradle/Kotlin error before adding more features.
