package com.neonwall.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.neonwall.app.ui.NeonWallApp
import com.neonwall.app.data.WeatherRepository
import com.neonwall.app.ui.theme.NeonWallTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent { NeonWallTheme { NeonWallApp() } }
    }

    override fun onStart() {
        super.onStart()
        // Ilova oldingi planda: joylashuvni o'qish mumkin. Fon ishchisi (WorkManager) keyin shuni ishlatadi.
        CoroutineScope(Dispatchers.IO).launch { WeatherRepository(applicationContext).rememberLocation() }
    }
}
