package com.neonwall.app.charging

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.BatteryManager
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neonwall.app.data.BatteryReader
import kotlinx.coroutines.delay
import kotlin.math.min

class ChargingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { MaterialTheme { ChargingShowScreen(onDismiss = { finish() }) } }
    }
}

@Composable
private fun ChargingShowScreen(onDismiss: () -> Unit) {
    var percent by remember { mutableIntStateOf(BatteryReader.read(androidx.compose.ui.platform.LocalContext.current).percent) }
    var temp by remember { mutableFloatStateOf(BatteryReader.read(androidx.compose.ui.platform.LocalContext.current).tempC) }
    var soundEnabled by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(0.45f) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val transition = rememberInfiniteTransition(label = "charge")
    val pulse by transition.animateFloat(0.72f, 1f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    LaunchedEffect(Unit) {
        while (true) {
            val info = BatteryReader.read(context)
            percent = info.percent
            temp = info.tempC
            delay(1500)
        }
    }
    DisposableEffect(soundEnabled, volume) {
        val tone = if (soundEnabled) ToneGenerator(AudioManager.STREAM_MUSIC, (volume * 100).toInt().coerceIn(0, 100)) else null
        onDispose { tone?.release() }
    }
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF090C12), Color(0xFF171D26), Color(0xFF080A0E))))
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { onDismiss() }) },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height * 0.38f
            val base = min(size.width, size.height) * 0.25f
            for (i in 0..2) {
                drawCircle(Color(0xFF82E8C2).copy(alpha = (0.18f - i * 0.04f) * pulse), base * (1.1f + i * 0.36f) * pulse, androidx.compose.ui.geometry.Offset(cx, cy), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()))
            }
            drawCircle(Color(0xFF82E8C2).copy(alpha = 0.13f), base, androidx.compose.ui.geometry.Offset(cx, cy))
            drawArc(Color(0xFF82E8C2), -90f, percent.coerceIn(0, 100) * 3.6f, false,
                androidx.compose.ui.geometry.Offset(cx - base, cy - base), androidx.compose.ui.geometry.Size(base * 2, base * 2), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 9.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
        }
        Column(Modifier.align(Alignment.Center).padding(top = 80.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("NEONWALL CHARGE", color = Color(0xFF82E8C2), fontSize = 13.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(220.dp))
            Text("$percent%", color = Color.White, fontSize = 54.sp, fontWeight = FontWeight.Light)
            Text(if (percent >= 100) "Batareya to‘ldi" else "Quvvatlanmoqda", color = Color(0xFFB6C3D1), fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            Text("Batareya harorati: %.1f°C".format(temp), color = Color(0xFFB6C3D1), fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Animatsiya ovozi", color = Color.White, modifier = Modifier.padding(end = 10.dp))
                Switch(checked = soundEnabled, onCheckedChange = { enabled ->
                    soundEnabled = enabled
                    if (enabled) runCatching {
                        ToneGenerator(AudioManager.STREAM_MUSIC, (volume * 100).toInt().coerceIn(0, 100)).apply {
                            startTone(ToneGenerator.TONE_PROP_ACK, 180)
                            release()
                        }
                    }
                })
            }
            Slider(value = volume, onValueChange = { volume = it }, enabled = soundEnabled, modifier = Modifier.padding(horizontal = 44.dp))
            Spacer(Modifier.height(12.dp))
            Button(onClick = onDismiss) { Text("YOPISH") }
            Text("Yopish uchun ikki marta teging", color = Color(0xFF82909F), fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
        }
    }
}
