package com.neonwall.app.charging

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.neonwall.app.R

/** Quvvat ulanganda ilovani yashirincha ochmaydi; foydalanuvchiga bildirishnoma beradi. */
class ChargingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> showNotification(context)
            Intent.ACTION_POWER_DISCONNECTED -> NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
        }
    }

    private fun showNotification(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, context.getString(R.string.charging_channel), NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val pending = PendingIntent.getActivity(
            context, 44, Intent(context, ChargingActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(context.getString(R.string.charging_notification_title))
            .setContentText(context.getString(R.string.charging_notification_text))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification) }
    }

    companion object {
        const val CHANNEL_ID = "neonwall_charging"
        const val NOTIFICATION_ID = 204
    }
}
