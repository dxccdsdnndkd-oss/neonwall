package com.neonwall.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream

data class NowPlaying(val title: String, val artist: String, val isPlaying: Boolean, val cover: Bitmap?)

/** MediaListenerService yozadi, Music vidjeti o'qiydi. Cover — 256x256 PNG (RemoteViews xotira limiti uchun). */
class NowPlayingStore(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("neonwall_nowplaying", Context.MODE_PRIVATE)
    private val coverFile = File(app.cacheDir, "cover.png")

    fun save(title: String, artist: String, playing: Boolean, cover: Bitmap?) {
        prefs.edit()
            .putBoolean("has", true).putString("title", title)
            .putString("artist", artist).putBoolean("playing", playing)
            .apply()
        if (cover != null) {
            runCatching {
                FileOutputStream(coverFile).use { squareScaled(cover).compress(Bitmap.CompressFormat.PNG, 90, it) }
            }
        } else {
            coverFile.delete()
        }
    }

    fun load(): NowPlaying? {
        if (!prefs.getBoolean("has", false)) return null
        val cover = if (coverFile.exists()) BitmapFactory.decodeFile(coverFile.path) else null
        return NowPlaying(
            title = prefs.getString("title", "").orEmpty(),
            artist = prefs.getString("artist", "").orEmpty(),
            isPlaying = prefs.getBoolean("playing", false),
            cover = cover,
        )
    }

    fun clear() {
        prefs.edit().clear().apply()
        coverFile.delete()
    }

    private fun squareScaled(src: Bitmap): Bitmap {
        val side = minOf(src.width, src.height)
        val cropped = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(cropped, 256, 256, true)
    }
}
