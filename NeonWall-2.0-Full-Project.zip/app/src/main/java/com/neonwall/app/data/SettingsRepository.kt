package com.neonwall.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate

/**
 * SharedPreferences asosidagi repository. DataStore o'rniga SharedPreferences tanlandi:
 * WallpaperService'ning main-thread render sikli sinxron o'qishga muhtoj.
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun load(): WallpaperSettings {
        val d = WallpaperSettings()
        return WallpaperSettings(
            parallaxEnabled = prefs.getBoolean(K_PARALLAX, d.parallaxEnabled),
            parallaxStrength = prefs.getFloat(K_PARALLAX_STRENGTH, d.parallaxStrength),
            touchEnabled = prefs.getBoolean(K_TOUCH, d.touchEnabled),
            audioEnabled = prefs.getBoolean(K_AUDIO, d.audioEnabled),
            dayNightEnabled = prefs.getBoolean(K_DAYNIGHT, d.dayNightEnabled),
            particleDensity = prefs.getFloat(K_DENSITY, d.particleDensity),
            maxFps = prefs.getInt(K_MAX_FPS, d.maxFps),
            accent = runCatching { AccentMode.valueOf(prefs.getString(K_ACCENT, null) ?: "AUTO") }
                .getOrDefault(AccentMode.AUTO),
            batteryThreshold = prefs.getInt(K_BATTERY, d.batteryThreshold),
            gameMode = prefs.getBoolean(K_GAME, d.gameMode),
        )
    }

    fun update(transform: (WallpaperSettings) -> WallpaperSettings) {
        val s = transform(load())
        prefs.edit()
            .putBoolean(K_PARALLAX, s.parallaxEnabled)
            .putFloat(K_PARALLAX_STRENGTH, s.parallaxStrength)
            .putBoolean(K_TOUCH, s.touchEnabled)
            .putBoolean(K_AUDIO, s.audioEnabled)
            .putBoolean(K_DAYNIGHT, s.dayNightEnabled)
            .putFloat(K_DENSITY, s.particleDensity)
            .putInt(K_MAX_FPS, s.maxFps)
            .putString(K_ACCENT, s.accent.name)
            .putInt(K_BATTERY, s.batteryThreshold)
            .putBoolean(K_GAME, s.gameMode)
            .apply()
    }

    fun observe(): Flow<WallpaperSettings> = callbackFlow {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> trySend(load()) }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(load())
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }.conflate()

    fun registerListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.registerOnSharedPreferenceChangeListener(l)

    fun unregisterListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(l)

    private companion object {
        const val NAME = "neonwall_settings"
        const val K_PARALLAX = "parallax"
        const val K_PARALLAX_STRENGTH = "parallax_strength"
        const val K_TOUCH = "touch"
        const val K_AUDIO = "audio"
        const val K_DAYNIGHT = "daynight"
        const val K_DENSITY = "density"
        const val K_MAX_FPS = "max_fps"
        const val K_ACCENT = "accent"
        const val K_BATTERY = "battery_threshold"
        const val K_GAME = "game_mode"
    }
}
