package com.neonwall.app.library

import android.app.Activity
import android.app.WallpaperManager
import android.widget.Toast
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neonwall.app.ui.components.NeonButton
import com.neonwall.app.ui.components.ScreenColumn
import com.neonwall.app.ui.components.ScreenHeader
import com.neonwall.app.ui.theme.Neon

private data class SceneInfo(val id: String, val name: String, val category: String, val description: String, val icon: String, val colors: List<Color>)
private val scenes = listOf(
    SceneInfo("aurora", "Qutb shu’lasi", "Tabiat", "Yumshoq harakatlanuvchi osmon nurlari", "〰", listOf(Color(0xFF14251F), Color(0xFF91B99A))),
    SceneInfo("rain", "Yomg‘ir oynasi", "Ob-havo", "Oynadagi yomg‘ir tomchilari", "☂", listOf(Color(0xFF18232B), Color(0xFF91AAB4))),
    SceneInfo("snow", "Sokin qor", "Ob-havo", "Sekin uchayotgan qor zarralari", "❄", listOf(Color(0xFF202A35), Color(0xFFB5C7D1))),
    SceneInfo("sakura", "Sakura", "Tabiat", "Shamolda uchayotgan gul yaproqlari", "✿", listOf(Color(0xFF2A1D24), Color(0xFFD79CA9))),
    SceneInfo("starfield", "Yulduzli tun", "Kosmos", "Chuqurlik hissi beruvchi yulduzlar", "✦", listOf(Color(0xFF10151F), Color(0xFF9DAAC5))),
    SceneInfo("galaxy", "Galaktika", "Kosmos", "Tumanlik ranglari va yulduzlar", "◉", listOf(Color(0xFF211A2B), Color(0xFF9C83B9))),
    SceneInfo("fire", "Cho‘g‘", "Abstrakt", "Yuqoriga ko‘tariluvchi issiq zarrachalar", "♨", listOf(Color(0xFF25140E), Color(0xFFE49A58))),
    SceneInfo("storm", "Chaqmoqli bo‘ron", "Ob-havo", "Vaqti-vaqti bilan chaqnashlar", "ϟ", listOf(Color(0xFF111823), Color(0xFF8496B9))),
    SceneInfo("ocean", "Okean to‘lqini", "Tabiat", "Qatlamli, sokin suv to‘lqinlari", "≋", listOf(Color(0xFF102126), Color(0xFF6DA2A0))),
    SceneInfo("fireflies", "Chiroqchalar", "Tabiat", "Qorong‘ida mayin yaltirashlar", "·", listOf(Color(0xFF182019), Color(0xFFB6B77C))),
    SceneInfo("bubbles", "Pufakchalar", "Abstrakt", "Yengil suzuvchi shaffof doiralar", "○", listOf(Color(0xFF172329), Color(0xFF8DB3B8))),
    SceneInfo("lava", "Lava lampasi", "Abstrakt", "Sekin qo‘shilib-ajraluvchi shakllar", "●", listOf(Color(0xFF251811), Color(0xFFD48C62))),
    SceneInfo("waves", "Rang to‘lqinlari", "Abstrakt", "Silliq gradient qatlamlari", "∿", listOf(Color(0xFF1E1C17), Color(0xFFB59B75))),
    SceneInfo("matrix", "Raqamlar yomg‘iri", "Raqamli", "Pastga oqadigan belgilar", "⌘", listOf(Color(0xFF111913), Color(0xFF87A77C))),
    SceneInfo("city", "Tungi shahar", "Shahar", "Derazalardagi iliq chiroqlar", "▥", listOf(Color(0xFF17191D), Color(0xFFD1A16A))),
    SceneInfo("clouds", "Suzuvchi bulutlar", "Tabiat", "Sekin siljiydigan bulutlar", "☁", listOf(Color(0xFF1A2026), Color(0xFF9EAEB2))),
    SceneInfo("geometry", "Aylanuvchi shakllar", "Abstrakt", "Minimal geometrik kompozitsiya", "◇", listOf(Color(0xFF201B16), Color(0xFFB7A17F))),
    SceneInfo("daynight", "Kun va tun", "Tabiat", "Mahalliy vaqtga mos rang almashinuvi", "◐", listOf(Color(0xFF24221B), Color(0xFFC7A36B))),
    SceneInfo("embers", "Uchqunlar", "Abstrakt", "Mayda uchqunlar va iliq nur", "✧", listOf(Color(0xFF20150F), Color(0xFFD18A5D))),
    SceneInfo("mist", "Tumanli vodiy", "Tabiat", "Past kontrastli tuman qatlamlari", "≋", listOf(Color(0xFF18201D), Color(0xFF9AA99A)))
)
private data class StaticInfo(val name: String, val file: String, val category: String)
private val wallpapers = listOf(
    StaticInfo("Sokin qum", "wallpaper_01.jpg", "Minimal"), StaticInfo("Qahrabo ufq", "wallpaper_02.jpg", "Issiq"),
    StaticInfo("Zaytun tumani", "wallpaper_03.jpg", "Tabiat"), StaticInfo("Terrakota", "wallpaper_04.jpg", "Issiq"),
    StaticInfo("Oy nuri", "wallpaper_05.jpg", "Sovuq"), StaticInfo("Yashil oqim", "wallpaper_06.jpg", "Tabiat"),
    StaticInfo("Mis orbitasi", "wallpaper_07.jpg", "Abstrakt"), StaticInfo("Ko‘k soat", "wallpaper_08.jpg", "Sovuq"),
    StaticInfo("Mayin cho‘g‘", "wallpaper_09.jpg", "Issiq"), StaticInfo("Tosh bog‘i", "wallpaper_10.jpg", "Minimal"),
    StaticInfo("Atirgul changi", "wallpaper_11.jpg", "Issiq"), StaticInfo("Yomg‘irdan so‘ng", "wallpaper_12.jpg", "Tabiat"),
    StaticInfo("Quyosh pardasi", "wallpaper_13.jpg", "Issiq"), StaticInfo("Siyoh gul", "wallpaper_14.jpg", "Abstrakt"),
    StaticInfo("Qish oynasi", "wallpaper_15.jpg", "Sovuq"), StaticInfo("Oltin don", "wallpaper_16.jpg", "Minimal"),
    StaticInfo("Bulut xaritasi", "wallpaper_17.jpg", "Sovuq"), StaticInfo("Qizil daraxt", "wallpaper_18.jpg", "Issiq"),
    StaticInfo("Sokin suv", "wallpaper_19.jpg", "Tabiat"), StaticInfo("Marvarid tutuni", "wallpaper_20.jpg", "Minimal"),
    StaticInfo("Mis halqalar", "wallpaper_21.jpg", "Abstrakt"), StaticInfo("Sokin yulduzlar", "wallpaper_22.jpg", "Kosmos"), StaticInfo("Qahrabo yomg‘ir", "wallpaper_23.jpg", "Issiq"), StaticInfo("Sage qatlamlar", "wallpaper_24.jpg", "Tabiat"), StaticInfo("Oy bog‘i", "wallpaper_25.jpg", "Sovuq"), StaticInfo("Kechki ufq", "wallpaper_26.jpg", "Issiq"), StaticInfo("Suv oynasi", "wallpaper_27.jpg", "Tabiat"), StaticInfo("Atirgul tuman", "wallpaper_28.jpg", "Sovuq"), StaticInfo("Qum tepalari", "wallpaper_29.jpg", "Minimal"), StaticInfo("Oltin orbit", "wallpaper_30.jpg", "Abstrakt"), StaticInfo("Yashil zarra", "wallpaper_31.jpg", "Tabiat"), StaticInfo("Tun geometriyasi", "wallpaper_32.jpg", "Abstrakt"), StaticInfo("Marvarid yoy", "wallpaper_33.jpg", "Sovuq"), StaticInfo("Cho‘g‘ chiziqlar", "wallpaper_34.jpg", "Issiq"), StaticInfo("Okean tusi", "wallpaper_35.jpg", "Tabiat"), StaticInfo("Binafsha fazo", "wallpaper_36.jpg", "Kosmos"), StaticInfo("Tosh va nur", "wallpaper_37.jpg", "Minimal"), StaticInfo("Yumshoq to‘lqin", "wallpaper_38.jpg", "Abstrakt"), StaticInfo("Qishki tuman", "wallpaper_39.jpg", "Sovuq"), StaticInfo("Terrakota halqa", "wallpaper_40.jpg", "Issiq"), StaticInfo("Zaytun ufqi", "wallpaper_41.jpg", "Tabiat"), StaticInfo("Yulduz changi", "wallpaper_42.jpg", "Kosmos"), StaticInfo("Mis chiziq", "wallpaper_43.jpg", "Abstrakt"), StaticInfo("Sokin kecha", "wallpaper_44.jpg", "Minimal"), StaticInfo("Oqish bulut", "wallpaper_45.jpg", "Sovuq"), StaticInfo("Qizg‘ish nur", "wallpaper_46.jpg", "Issiq"), StaticInfo("Suv marjoni", "wallpaper_47.jpg", "Tabiat"), StaticInfo("Ko‘mir va oltin", "wallpaper_48.jpg", "Minimal"), StaticInfo("Tumanli bog‘", "wallpaper_49.jpg", "Tabiat"), StaticInfo("Oxirgi quyosh", "wallpaper_50.jpg", "Issiq")
)

@Composable
fun LibraryScreen(onApplyLive: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("neonwall_library", 0) }
    var section by rememberSaveable { mutableStateOf("Jonli") }
    var query by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("Barchasi") }
    var favoritesOnly by rememberSaveable { mutableStateOf(false) }
    var selected by rememberSaveable { mutableStateOf(prefs.getString("selected_scene", "aurora") ?: "aurora") }
    var favoriteIds by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    ScreenColumn {
        ScreenHeader("NEONWALL", "Fonlar kutubxonasi · o‘zingizga mos kayfiyat")
        Text("Rang uslubi", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
        val paletteOptions = listOf("Mis" to 0xFFD99A68, "Sage" to 0xFF879B87, "Oltin" to 0xFFE1B77E, "Ko‘k" to 0xFF8CA9C4, "Atirgul" to 0xFFC18B91, "Binafsha" to 0xFFA99AC7)
        var paletteIndex by remember { mutableStateOf(prefs.getInt("palette_index", 0)) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            paletteOptions.forEachIndexed { index, pair ->
                FilterChip(selected = paletteIndex == index, onClick = {
                    paletteIndex = index
                    prefs.edit().putInt("palette_index", index).apply()
                    (context as? Activity)?.recreate()
                }, label = { Text(pair.first, fontSize = 11.sp) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = prefs.getBoolean("dynamic_color", false), onClick = {
                prefs.edit().putBoolean("dynamic_color", !prefs.getBoolean("dynamic_color", false)).apply()
                (context as? Activity)?.recreate()
            }, label = { Text("Material You") })
            FilterChip(selected = prefs.getBoolean("amoled_black", true), onClick = {
                prefs.edit().putBoolean("amoled_black", !prefs.getBoolean("amoled_black", true)).apply()
                (context as? Activity)?.recreate()
            }, label = { Text("AMOLED qora") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Jonli", "Statik").forEach { tab ->
                FilterChip(selected = section == tab, onClick = { section = tab; category = "Barchasi" }, label = { Text(tab) })
            }
            FilterChip(selected = favoritesOnly, onClick = { favoritesOnly = !favoritesOnly }, label = { Text(if (favoritesOnly) "♥ Tanlangan" else "♡ Sevimlilar") })
        }
        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .6f), modifier = Modifier.fillMaxWidth()) {
            BasicTextField(value = query, onValueChange = { query = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                textStyle = androidx.compose.ui.text.TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp),
                decorationBox = { inner -> if (query.isEmpty()) Text("Qidirish…", color = Neon.TextDim); inner() })
        }
        val categories = if (section == "Jonli") listOf("Barchasi", "Tabiat", "Ob-havo", "Kosmos", "Abstrakt", "Raqamli", "Shahar") else listOf("Barchasi", "Minimal", "Issiq", "Sovuq", "Tabiat", "Abstrakt")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEach { cat -> FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat, fontSize = 11.sp) }) }
        }
        if (section == "Jonli") {
            val filtered = scenes.filter { (category == "Barchasi" || it.category == category) && it.name.contains(query, true) && (!favoritesOnly || it.id in favoriteIds) }
            Text("${filtered.size} ta jonli sahna", color = Neon.TextDim, fontSize = 12.sp)
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().height(560.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(filtered, key = { it.id }) { scene ->
                    val active = selected == scene.id
                    Column(Modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).clickable {
                        selected = scene.id; prefs.edit().putString("selected_scene", scene.id).apply()
                    }.padding(10.dp)) {
                        Box(Modifier.fillMaxWidth().aspectRatio(.78f).clip(RoundedCornerShape(12.dp)).background(androidx.compose.ui.graphics.Brush.linearGradient(scene.colors)), contentAlignment = Alignment.Center) {
                            Text(scene.icon, color = Color.White.copy(.9f), fontSize = 48.sp, fontWeight = FontWeight.Light)
                            Text(if (active) "TANLANGAN" else "LIVE", modifier = Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(.45f)).padding(horizontal = 7.dp, vertical = 4.dp), color = Color.White, fontSize = 9.sp)
                            Text(if (scene.id in favoriteIds) "♥" else "♡", modifier = Modifier.align(Alignment.TopEnd).clickable {
                                favoriteIds = if (scene.id in favoriteIds) favoriteIds - scene.id else favoriteIds + scene.id
                                prefs.edit().putStringSet("favorites", favoriteIds).apply()
                            }.padding(8.dp), color = Color.White, fontSize = 18.sp)
                        }
                        Spacer(Modifier.height(8.dp)); Text(scene.name, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(scene.description, color = Neon.TextDim, fontSize = 11.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 3.dp))
                        Text("3 sozlama · ${scene.category}", color = Neon.Cyan, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            Text("Tanlangan sahna: ${scenes.firstOrNull { it.id == selected }?.name ?: "Qutb shu’lasi"}", color = Neon.TextDim, fontSize = 12.sp)
            NeonButton("JONLI FONNI O‘RNATISH", onClick = onApplyLive)
        } else {
            val filtered = wallpapers.filter { (category == "Barchasi" || it.category == category) && it.name.contains(query, true) && (!favoritesOnly || it.file in favoriteIds) }
            Text("${filtered.size} ta original statik fon", color = Neon.TextDim, fontSize = 12.sp)
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().height(560.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(filtered, key = { it.file }) { wallpaper ->
                    val bitmap = remember(wallpaper.file) { runCatching { context.assets.open("wallpapers/${wallpaper.file}").use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }.getOrNull() }
                    Column(Modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).clickable {
                        runCatching {
                            context.assets.open("wallpapers/${wallpaper.file}").use { stream ->
                                val fullBitmap = BitmapFactory.decodeStream(stream)
                                if (fullBitmap != null) WallpaperManager.getInstance(context).setBitmap(fullBitmap)
                            }
                        }.onSuccess { Toast.makeText(context, "Fon bosh ekranga o‘rnatildi", Toast.LENGTH_SHORT).show() }
                            .onFailure { Toast.makeText(context, "Fon o‘rnatilmadi. Qayta urinib ko‘ring.", Toast.LENGTH_LONG).show() }
                    }.padding(8.dp)) {
                        Box(Modifier.fillMaxWidth().aspectRatio(.62f).clip(RoundedCornerShape(10.dp))) {
                            if (bitmap != null) Image(bitmap, contentDescription = wallpaper.name, modifier = Modifier.fillMaxSize())
                            Text(if (wallpaper.file in favoriteIds) "♥" else "♡", modifier = Modifier.align(Alignment.TopEnd).clickable {
                                favoriteIds = if (wallpaper.file in favoriteIds) favoriteIds - wallpaper.file else favoriteIds + wallpaper.file
                                prefs.edit().putStringSet("favorites", favoriteIds).apply()
                            }.padding(8.dp), color = Color.White, fontSize = 18.sp)
                        }
                        Text(wallpaper.name, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                        Text(wallpaper.category, color = Neon.TextDim, fontSize = 11.sp)
                    }
                }
            }
            Text("Rasmlar NeonWall uchun generatsiya qilingan; uchinchi tomon tasvirlari ishlatilmagan.", color = Neon.TextDim, fontSize = 12.sp)
        }
    }
}
