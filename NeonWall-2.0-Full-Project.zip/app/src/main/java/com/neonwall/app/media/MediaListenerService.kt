package com.neonwall.app.media

import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import androidx.glance.appwidget.updateAll
import com.neonwall.app.data.NowPlayingStore
import com.neonwall.app.widget.MusicWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Faol media sessiyalarini (Spotify, YouTube Music, ...) kuzatish uchun Android faqat
 * NotificationListener ruxsati bor komponentga ruxsat beradi. Servis hech qanday bildirishnomani o'qimaydi —
 * faqat MediaSessionManager'ga "kirish bileti" sifatida xizmat qiladi.
 *
 * Ruxsat berilganda tizim servisni o'zi bog'laydi (onListenerConnected). Servis uzilsa (OEM/xotira) —
 * onListenerDisconnected ichida requestRebind() chaqiriladi; ruxsat bekor qilingan bo'lsa u hech narsa qilmaydi.
 */
class MediaListenerService : NotificationListenerService() {

    private class Track(val title: String, val artist: String, val playing: Boolean, val cover: Bitmap?)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    // Metadata/state callback'lari ketma-ket kelganda cover.png ga parallel yozilmasligi uchun
    private val writeMutex = Mutex()
    private var sessionManager: MediaSessionManager? = null
    private var component: ComponentName? = null
    private var controller: MediaController? = null

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        // Sessiya o'ldi: boshqa faol sessiyani qidiramiz (eskisini ko'rsatib qolmaymiz)
        override fun onSessionDestroyed() = rescanSessions()
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list.orEmpty())
    }

    override fun onListenerConnected() {
        val comp = ComponentName(this, MediaListenerService::class.java)
        val manager = getSystemService(MediaSessionManager::class.java)
        component = comp
        sessionManager = manager
        runCatching { manager.removeOnActiveSessionsChangedListener(sessionsListener) }  // qayta ulanishda dublikat bo'lmasin
        try {
            manager.addOnActiveSessionsChangedListener(sessionsListener, comp)
            bind(manager.getActiveSessions(comp))
        } catch (ignored: SecurityException) {   // `_` catch parametri sifatida Kotlin 2.0.21 da kafolatlanmagan
            // Ruxsat shu zahoti bekor qilingan; tizim o'zi onListenerDisconnected chaqiradi
        }
    }

    override fun onListenerDisconnected() {
        sessionManager?.let { runCatching { it.removeOnActiveSessionsChangedListener(sessionsListener) } }
        controller?.unregisterCallback(controllerCallback)
        controller = null
        // requestRebind — statik metod: aniq klass nomi bilan chaqiramiz (superklass statikasiga tayanmaymiz)
        component?.let { runCatching { NotificationListenerService.requestRebind(it) } }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun rescanSessions() {
        val manager = sessionManager ?: return
        val comp = component ?: return
        runCatching { bind(manager.getActiveSessions(comp)) }
    }

    /** Chalinayotgan sessiyani, bo'lmasa birinchisini tanlaydi. */
    private fun bind(sessions: List<MediaController>) {
        val best = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: sessions.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(controllerCallback)
            controller = best
            best?.registerCallback(controllerCallback)
        }
        publish()
    }

    /** Ma'lumot main thread'da yig'iladi (controller shu yerda ishlatiladi), diskka yozish esa ketma-ket. */
    private fun publish() {
        val current = controller
        val metadata = current?.metadata
        val track = if (current == null || metadata == null) null else Track(
            title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown",
            artist = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST).orEmpty(),
            playing = current.playbackState?.state == PlaybackState.STATE_PLAYING,
            cover = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART),
        )
        scope.launch {
            writeMutex.withLock {
                val store = NowPlayingStore(applicationContext)
                if (track == null) store.clear() else store.save(track.title, track.artist, track.playing, track.cover)
                runCatching { MusicWidget().updateAll(applicationContext) }
            }
        }
    }
}
