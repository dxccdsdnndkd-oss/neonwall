package com.neonwall.app.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/** Lightweight photo wallpaper renderer. It keeps one downsampled bitmap and reuses Paint/RectF. */
class PhotoWallpaperRenderer(private val context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()
    private var loadedUri: String? = null
    private var bitmap: Bitmap? = null
    private var elapsed = 0f
    private val particleX = FloatArray(72) { Random.nextFloat() }
    private val particleY = FloatArray(72) { Random.nextFloat() }
    private val particleSpeed = FloatArray(72) { 0.03f + Random.nextFloat() * 0.12f }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    fun isEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, false) && !prefs.getString(KEY_URI, null).isNullOrBlank()

    fun draw(canvas: Canvas, width: Float, height: Float, dt: Float) {
        if (width <= 0f || height <= 0f) return
        val uriText = prefs.getString(KEY_URI, null)
        if (uriText.isNullOrBlank()) return
        if (loadedUri != uriText || bitmap == null) load(uriText)
        val image = bitmap ?: run { canvas.drawColor(Color.BLACK); return }
        elapsed = (elapsed + dt.coerceIn(0f, 0.05f)) % 600f
        val scaleBase = max(width / image.width, height / image.height)
        val kenBurns = if (prefs.getBoolean(KEY_KEN_BURNS, true)) 1f + 0.045f * (0.5f + 0.5f * sin(elapsed * 0.18f)) else 1f
        val drawW = image.width * scaleBase * kenBurns
        val drawH = image.height * scaleBase * kenBurns
        val panX = (width - drawW) * (0.5f + 0.08f * sin(elapsed * 0.11f))
        val panY = (height - drawH) * (0.5f + 0.08f * sin(elapsed * 0.09f))
        dst.set(panX, panY, panX + drawW, panY + drawH)
        paint.colorFilter = when (prefs.getString(KEY_FILTER, FILTER_NONE)) {
            FILTER_WARM -> ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                1.12f, 0f, 0f, 0f, 8f, 0f, 1.02f, 0f, 0f, 2f, 0f, 0f, 0.88f, 0f, 0f, 0f, 0f, 0f, 1f, 0f
            )))
            FILTER_COOL -> ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                0.92f, 0f, 0f, 0f, 0f, 0f, 1.02f, 0f, 0f, 0f, 0f, 0f, 1.12f, 0f, 8f, 0f, 0f, 0f, 1f, 0f
            )))
            FILTER_MONO -> ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
            else -> null
        }
        canvas.drawBitmap(image, null, dst, paint)
        paint.colorFilter = null
        if (prefs.getBoolean(KEY_PARTICLES, false)) drawParticles(canvas, width, height, dt)
        if (prefs.getBoolean(KEY_VIGNETTE, false)) {
            val vignette = Paint(Paint.ANTI_ALIAS_FLAG)
            vignette.shader = android.graphics.RadialGradient(width / 2f, height / 2f, max(width, height) * 0.72f,
                intArrayOf(Color.TRANSPARENT, Color.argb(150, 0, 0, 0)), null, android.graphics.Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, width, height, vignette)
        }
    }

    private fun drawParticles(canvas: Canvas, width: Float, height: Float, dt: Float) {
        val intensity = prefs.getFloat("particle_intensity", 0.5f).coerceIn(0f, 1f)
        val count = (particleX.size * intensity).toInt()
        for (i in 0 until count) {
            particleY[i] += particleSpeed[i] * dt
            if (particleY[i] > 1f) { particleY[i] = 0f; particleX[i] = Random.nextFloat() }
            particlePaint.alpha = (90 + 130 * (0.5 + 0.5 * sin(elapsed * 2.0 + i))).toInt().coerceIn(50, 220)
            val radius = if (i % 4 == 0) 2.4f else 1.2f
            canvas.drawCircle(particleX[i] * width, particleY[i] * height, radius, particlePaint)
        }
    }

    private fun load(uriText: String) {
        loadedUri = uriText
        bitmap?.recycle()
        bitmap = null
        runCatching {
            val uri = Uri.parse(uriText)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val sample = max(1, max(bounds.outWidth / 1440, bounds.outHeight / 2560))
            val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        }.onSuccess { bitmap = it }
    }

    companion object {
        const val PREFS = "neonwall_photo_live"
        const val KEY_ENABLED = "photo_enabled"
        const val KEY_URI = "photo_uri"
        const val KEY_KEN_BURNS = "ken_burns"
        const val KEY_PARTICLES = "photo_particles"
        const val KEY_VIGNETTE = "photo_vignette"
        const val KEY_FILTER = "photo_filter"
        const val FILTER_NONE = "none"
        const val FILTER_WARM = "warm"
        const val FILTER_COOL = "cool"
        const val FILTER_MONO = "mono"
    }
}
