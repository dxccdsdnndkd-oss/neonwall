package com.neonwall.app.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.neonwall.app.R
import com.neonwall.app.ui.components.GlassCard
import com.neonwall.app.ui.components.NeonButton
import com.neonwall.app.ui.components.ScreenColumn
import com.neonwall.app.ui.components.ScreenHeader
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private data class EditorLayer(val id: Int, val type: String, val title: String, val x: Float = .5f, val y: Float = .5f, val size: Float = .5f, val opacity: Float = 1f, val locked: Boolean = false)

@Composable
fun CreatorScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("neonwall_creator", Context.MODE_PRIVATE) }
    var projectName by remember { mutableStateOf(prefs.getString("project_name", "Mening fonim") ?: "Mening fonim") }
    var activeSection by remember { mutableStateOf("Qatlamlar") }
    val layers = remember { mutableStateListOf<EditorLayer>().apply {
        if (isEmpty()) {
            add(EditorLayer(1, "Gradient", "Fon gradienti"))
            add(EditorLayer(2, "Clock", "Raqamli soat", .5f, .22f, .7f))
            add(EditorLayer(3, "Particles", "Yulduz zarralari", .5f, .7f, .35f))
        }
    } }
    var nextId by remember { mutableStateOf(4) }
    var selectedIndex by remember { mutableStateOf(0) }
    var undoSnapshot by remember { mutableStateOf<List<EditorLayer>?>(null) }
    var shortcutLabel by remember { mutableStateOf("NeonWall") }
    var shortcutGlyph by remember { mutableStateOf("✦") }
    var shortcutColor by remember { mutableStateOf(0xFFD99A68.toInt()) }
    var shortcutShape by remember { mutableStateOf("Yumaloq") }
    var shortcutImage by remember { mutableStateOf<Bitmap?>(null) }
    var shortcutImageUri by remember { mutableStateOf<Uri?>(null) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                loadShortcutBitmap(context, uri)
            }.onSuccess { bitmap ->
                if (bitmap != null) { shortcutImage = bitmap; shortcutImageUri = uri }
            }.onFailure { Toast.makeText(context, "Rasmni ochib bo‘lmadi", Toast.LENGTH_SHORT).show() }
        }
    }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            val project = createProjectJson(projectName, layers)
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    ZipOutputStream(output).use { zip ->
                        zip.putNextEntry(ZipEntry("project.json")); zip.write(project.toByteArray(Charsets.UTF_8)); zip.closeEntry()
                        shortcutImage?.let { bitmap ->
                            zip.putNextEntry(ZipEntry("assets/shortcut.png"))
                            val bytes = java.io.ByteArrayOutputStream()
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes)
                            zip.write(bytes.toByteArray()); zip.closeEntry()
                        }
                    }
                } ?: error("Faylni yozib bo‘lmadi")
            }.onSuccess { Toast.makeText(context, "NeonPack eksport qilindi", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(context, "Eksport xatosi: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input).use { zip ->
                        var entry = zip.nextEntry
                        var json = ""
                        while (entry != null) {
                            if (entry.name == "project.json") json = BufferedReader(InputStreamReader(zip, Charsets.UTF_8)).readText()
                            zip.closeEntry(); entry = zip.nextEntry
                        }
                        require(json.isNotBlank()) { "project.json topilmadi" }
                        JSONObject(json)
                    }
                } ?: error("Faylni o‘qib bo‘lmadi")
            }.onSuccess { json ->
                projectName = json.optString("name", "Import qilingan loyiha")
                val imported = json.optJSONArray("layers") ?: JSONArray()
                layers.clear()
                for (i in 0 until imported.length()) {
                    val item = imported.optJSONObject(i) ?: continue
                    layers.add(EditorLayer(item.optInt("id", i + 1), item.optString("type", "Text"), item.optString("title", "Qatlam ${i + 1}"), item.optDouble("x", .5).toFloat(), item.optDouble("y", .5).toFloat(), item.optDouble("size", .5).toFloat(), item.optDouble("opacity", 1.0).toFloat(), item.optBoolean("locked", false)))
                }
                if (layers.isEmpty()) layers.add(EditorLayer(1, "Gradient", "Fon gradienti"))
                selectedIndex = 0
                Toast.makeText(context, "NeonPack import qilindi", Toast.LENGTH_LONG).show()
            }.onFailure { Toast.makeText(context, "NeonPack xato: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }

    ScreenColumn {
        ScreenHeader("NEONWALL STUDIO", "Qatlamlar, ikonka va loyiha fayllari")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Qatlamlar", "Ikonka", "NeonPack").forEach { item ->
                FilterChip(selected = activeSection == item, onClick = { activeSection = item }, label = { Text(item) })
            }
        }
        when (activeSection) {
            "Qatlamlar" -> {
                GlassCard {
                    OutlinedTextField(value = projectName, onValueChange = { projectName = it }, label = { Text("Loyiha nomi") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Text("Qatlamlar soni: ${layers.size}", color = MaterialTheme.colorScheme.onSurface)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Rasm", "Matn", "Soat", "Sana", "Gradient", "Zarralar", "Shakl").forEach { type ->
                            FilterChip(selected = false, onClick = {
                                undoSnapshot = layers.toList()
                                layers.add(EditorLayer(nextId++, type, when(type) { "Rasm" -> "Rasm qatlami"; "Matn" -> "Matn qatlami"; "Soat" -> "Soat"; "Sana" -> "Sana"; "Gradient" -> "Gradient"; "Zarralar" -> "Zarralar"; else -> "Shakl" }))
                                selectedIndex = layers.lastIndex
                            }, label = { Text(type, fontSize = 11.sp) })
                        }
                    }
                    LazyColumn(modifier = Modifier.fillMaxWidth().height(230.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        itemsIndexed(layers, key = { _, layer -> layer.id }) { index, layer ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (index == selectedIndex) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant).clickable { selectedIndex = index }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(layer.title, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                                    Text("${layer.type} · ${(layer.x * 100).toInt()}%, ${(layer.y * 100).toInt()}%", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                                }
                                Text(if (layer.locked) "🔒" else "◇", modifier = Modifier.clickable { layers[index] = layer.copy(locked = !layer.locked) }.padding(4.dp))
                                Text("↑", modifier = Modifier.clickable { if (index > 0) { val a = layers[index - 1]; layers[index - 1] = layers[index]; layers[index] = a; selectedIndex = index - 1 } }.padding(4.dp))
                                Text("↓", modifier = Modifier.clickable { if (index < layers.lastIndex) { val a = layers[index + 1]; layers[index + 1] = layers[index]; layers[index] = a; selectedIndex = index + 1 } }.padding(4.dp))
                                Text("＋", modifier = Modifier.clickable { layers.add(index + 1, layer.copy(id = nextId++, title = "${layer.title} nusxa", locked = false)); selectedIndex = index + 1 }.padding(4.dp))
                                Text("×", modifier = Modifier.clickable { if (!layer.locked && layers.size > 1) { layers.removeAt(index); selectedIndex = (selectedIndex - 1).coerceAtLeast(0) } }.padding(4.dp))
                            }
                        }
                    }
                    if (layers.isNotEmpty()) {
                        val index = selectedIndex.coerceIn(0, layers.lastIndex)
                        val selected = layers[index]
                        Text("Joylashuv X · ${(selected.x * 100).toInt()}%", color = MaterialTheme.colorScheme.onSurface)
                        Slider(value = selected.x, onValueChange = { if (!selected.locked) layers[index] = selected.copy(x = it) }, valueRange = 0f..1f)
                        Text("Joylashuv Y · ${(selected.y * 100).toInt()}%", color = MaterialTheme.colorScheme.onSurface)
                        Slider(value = selected.y, onValueChange = { if (!selected.locked) layers[index] = selected.copy(y = it) }, valueRange = 0f..1f)
                        Text("O‘lcham · ${(selected.size * 100).toInt()}%", color = MaterialTheme.colorScheme.onSurface)
                        Slider(value = selected.size, onValueChange = { if (!selected.locked) layers[index] = selected.copy(size = it) }, valueRange = .1f..1f)
                        Text("Shaffoflik · ${(selected.opacity * 100).toInt()}%", color = MaterialTheme.colorScheme.onSurface)
                        Slider(value = selected.opacity, onValueChange = { if (!selected.locked) layers[index] = selected.copy(opacity = it) }, valueRange = 0f..1f)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { undoSnapshot?.let { layers.clear(); layers.addAll(it); selectedIndex = 0 }; undoSnapshot = null }) { Text("Bekor qilish") }
                        Button(onClick = { prefs.edit().putString("project_name", projectName).putString("project_json", createProjectJson(projectName, layers)).apply(); Toast.makeText(context, "Loyiha telefonga saqlandi", Toast.LENGTH_SHORT).show() }) { Text("Saqlash") }
                    }
                }
            }
            "Ikonka" -> {
                GlassCard {
                    Text("Ilova uchun pinned shortcut yarating", color = MaterialTheme.colorScheme.onSurface)
                    Text("Android o‘rnatilgan ilova belgisini istalgan rasmga bevosita almashtirishga ruxsat bermaydi. Bu yerda bosh ekranga alohida yorliq qo‘shiladi.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    OutlinedTextField(value = shortcutLabel, onValueChange = { shortcutLabel = it }, label = { Text("Yorliq nomi") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = shortcutGlyph, onValueChange = { shortcutGlyph = it.take(3) }, label = { Text("Emoji yoki belgi") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Doira", "Kvadrat", "Yumaloq").forEach { shape -> FilterChip(selected = shortcutShape == shape, onClick = { shortcutShape = shape }, label = { Text(shape) }) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0xFFD99A68.toInt(), 0xFF879B87.toInt(), 0xFF8CA9C4.toInt(), 0xFFC18B91.toInt(), 0xFF151515.toInt()).forEach { color ->
                            Box(Modifier.size(34.dp).clip(RoundedCornerShape(50)).background(Color(color)).clickable { shortcutColor = color })
                        }
                    }
                    NeonButton("RASMDAN IKKONKA TANLASH") { imagePicker.launch(arrayOf("image/*")) }
                    if (shortcutImageUri != null) Text("Rasm tanlandi", color = MaterialTheme.colorScheme.primary)
                    NeonButton("BOSH EKRANGA YORLIQ QO‘SHISH") {
                        runCatching {
                            if (Build.VERSION.SDK_INT < 26) error("Pinned shortcut Android 8.0 yoki yangiroq versiyani talab qiladi")
                            val manager = context.getSystemService(ShortcutManager::class.java)
                            if (!manager.isRequestPinShortcutSupported) error("Launcher pinned shortcutni qo‘llamaydi")
                            val bitmap = shortcutImage?.let { Bitmap.createScaledBitmap(it, 256, 256, true) } ?: makeShortcutBitmap(shortcutGlyph, shortcutColor, shortcutShape)
                            val intent = context.packageManager.getLaunchIntentForPackage(context.packageName) ?: Intent(context, MainActivity::class.java)
                            val info = ShortcutInfo.Builder(context, "neonwall_shortcut_${System.currentTimeMillis()}")
                                .setShortLabel(shortcutLabel.ifBlank { "NeonWall" }.take(40))
                                .setLongLabel(shortcutLabel.ifBlank { "NeonWall" }.take(80))
                                .setIcon(Icon.createWithBitmap(bitmap))
                                .setIntent(intent).build()
                            manager.requestPinShortcut(info, null)
                        }.onSuccess { Toast.makeText(context, "Yorliq so‘rovi yuborildi. Launcher tasdiqlash oynasini ko‘rsatishi mumkin.", Toast.LENGTH_LONG).show() }
                            .onFailure { Toast.makeText(context, "Yorliq yaratilmadi: ${it.message}", Toast.LENGTH_LONG).show() }
                    }
                }
                GlassCard {
                    Text("10 ta ilova belgisi", color = MaterialTheme.colorScheme.onSurface)
                    Text("Belgini tanlash launcher keshini yangilash uchun bir necha soniya talab qilishi mumkin.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    val iconNames = listOf("Asl", "Qahrabo", "Sage", "Ko‘k", "Atirgul", "Oltin", "Tungi", "Marvarid", "Terrakota", "Minimal")
                    iconNames.forEachIndexed { index, name ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(name, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                            Button(onClick = { setLauncherAlias(context, index); Toast.makeText(context, "Belgi almashtirildi. Launcher yangilanishi biroz vaqt olishi mumkin.", Toast.LENGTH_LONG).show() }) { Text("Tanlash") }
                        }
                    }
                }
            }
            else -> {
                GlassCard {
                    Text(".neonpack — loyiha va resurslar", color = MaterialTheme.colorScheme.onSurface)
                    Text("Loyiha JSON fayli va tanlangan yorliq rasmi bitta ZIP arxivga joylanadi. Boshqa qurilmada import qilish mumkin.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    NeonButton(".NEONPACK EKSPORT QILISH") { exportPicker.launch("${projectName.ifBlank { "NeonWall" }}.neonpack") }
                    NeonButton(".NEONPACK IMPORT QILISH") { importPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
                    Text("Saqlangan loyiha: ${prefs.getString("project_name", "Hali saqlanmagan")}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

private fun createProjectJson(name: String, layers: List<EditorLayer>): String {
    val root = JSONObject().put("format", "neonpack").put("version", 1).put("name", name)
    val array = JSONArray()
    layers.forEach { layer -> array.put(JSONObject().put("id", layer.id).put("type", layer.type).put("title", layer.title).put("x", layer.x.toDouble()).put("y", layer.y.toDouble()).put("size", layer.size.toDouble()).put("opacity", layer.opacity.toDouble()).put("locked", layer.locked)) }
    root.put("layers", array)
    return root.toString(2)
}

private fun loadShortcutBitmap(context: Context, uri: Uri): Bitmap? {
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > 768 || bounds.outHeight / sample > 768) sample *= 2
    val options = android.graphics.BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, options) }
}

private fun makeShortcutBitmap(glyph: String, color: Int, shape: String): Bitmap {
    val bitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val background = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
    when (shape) {
        "Doira" -> canvas.drawCircle(128f, 128f, 120f, background)
        "Kvadrat" -> canvas.drawRect(8f, 8f, 248f, 248f, background)
        else -> canvas.drawRoundRect(RectF(8f, 8f, 248f, 248f), 54f, 54f, background)
    }
    val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = android.graphics.Color.WHITE; textSize = 110f; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    canvas.drawText(glyph.ifBlank { "✦" }, 128f, 166f, text)
    return bitmap
}

private fun setLauncherAlias(context: Context, index: Int) {
    val aliases = listOf("IconOriginal", "IconAmber", "IconSage", "IconBlue", "IconRose", "IconGold", "IconNight", "IconPearl", "IconTerra", "IconMinimal")
    aliases.forEachIndexed { i, alias ->
        val component = ComponentName(context, "${context.packageName}.$alias")
        context.packageManager.setComponentEnabledSetting(component,
            if (i == index) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP)
    }
}
