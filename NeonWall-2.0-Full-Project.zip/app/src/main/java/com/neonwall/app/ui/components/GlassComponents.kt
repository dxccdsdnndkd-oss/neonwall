package com.neonwall.app.ui.components

import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neonwall.app.ui.theme.Neon

/** AMOLED qora fon + ikkita xira neon "blob" (Android 12+ da RenderEffect orqali Modifier.blur). */
@Composable
fun NeonBackground(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Neon.Void)) {
        Blob(Neon.Cyan.copy(alpha = 0.35f), 320.dp, Modifier.align(Alignment.TopEnd).offset(x = 90.dp, y = (-80).dp))
        Blob(Neon.Magenta.copy(alpha = 0.28f), 280.dp, Modifier.align(Alignment.BottomStart).offset(x = (-100).dp, y = 60.dp))
        content()
    }
}

@Composable
private fun Blob(color: Color, size: Dp, modifier: Modifier) {
    Box(
        modifier
            .size(size)
            .then(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Modifier.blur(70.dp) else Modifier)
            .background(Brush.radialGradient(listOf(color, Color.Transparent)), CircleShape)
    )
}

/** Glassmorphism: shaffof gradient + yupqa neon chegara. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    accent: Color = Neon.Cyan,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(0.10f), Color.White.copy(0.03f))))
            .border(
                1.dp,
                Brush.linearGradient(listOf(accent.copy(0.55f), Color.White.copy(0.05f), Neon.Magenta.copy(0.35f))),
                shape,
            )
            .padding(20.dp),
        content = content,
    )
}

@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        content = content,
    )
}

@Composable
fun ScreenHeader(title: String, subtitle: String) {
    Column(Modifier.padding(top = 8.dp)) {
        Text(title, color = Neon.Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(subtitle, color = Neon.TextDim, fontSize = 13.sp)
    }
}

@Composable
fun SectionTitle(text: String, color: Color = Neon.Cyan) {
    Text(text.uppercase(), color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Neon.TextPrimary, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Neon.TextDim, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black, checkedTrackColor = Neon.Cyan,
                uncheckedThumbColor = Neon.TextDim, uncheckedTrackColor = Color.White.copy(0.08f),
                uncheckedBorderColor = Color.White.copy(0.2f),
            ),
        )
    }
}

@Composable
fun SliderRow(
    label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>,
    steps: Int = 0, onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = Neon.TextPrimary, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(valueText, color = Neon.Cyan, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range, steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = Neon.Cyan, activeTrackColor = Neon.Cyan, inactiveTrackColor = Color.White.copy(0.12f),
            ),
        )
    }
}

@Composable
fun NeonButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Neon.Cyan.copy(0.28f), Neon.Magenta.copy(0.28f))))
            .border(1.dp, Neon.Cyan.copy(0.6f), shape)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Neon.TextPrimary, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
    }
}

@Composable
fun GlassNavBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf("▦" to "Kutub", "▧" to "Photo", "◈" to "Sozla", "✦" to "Studio", "▤" to "Vidjet", "ϟ" to "Quvvat")
    val shape = RoundedCornerShape(32.dp)
    Row(
        Modifier
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Color.White.copy(0.07f))
            .border(1.dp, Color.White.copy(0.12f), shape)
            .padding(6.dp),
    ) {
        items.forEachIndexed { i, (glyph, label) ->
            val active = i == selected
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(26.dp))
                    .background(if (active) Neon.Cyan.copy(0.16f) else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(glyph, color = if (active) Neon.Cyan else Neon.TextDim, fontSize = 18.sp)
                Text(label, color = if (active) Neon.Cyan else Neon.TextDim, fontSize = 11.sp)
            }
        }
    }
}

/** Ilova ichidagi mini jonli ko'rinish (haqiqiy wallpaper'ning soddalashtirilgan nusxasi). */
@Composable
fun LivePreview(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "preview")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
    Canvas(modifier.clip(RoundedCornerShape(24.dp)).background(Color.Black)) {
        val w = size.width
        val h = size.height
        val horizon = h * 0.6f
        drawRect(Brush.verticalGradient(listOf(Color.Black, Color(0xFF050A1A))), size = Size(w, h))
        val orb = Offset(w * 0.72f, h * 0.25f)
        drawCircle(Brush.radialGradient(listOf(Neon.Cyan.copy(0.45f), Color.Transparent), center = orb, radius = w * 0.45f), radius = w * 0.45f, center = orb)
        for (k in 0 until 8) {
            val p = (k + t) / 8f
            val y = horizon + (h - horizon) * p * p
            drawLine(Neon.Cyan.copy(0.15f + 0.5f * p), Offset(0f, y), Offset(w, y), 2f)
        }
        for (i in -6..6) drawLine(Neon.Cyan.copy(0.35f), Offset(w / 2, horizon), Offset(w / 2 + i * w * 0.18f, h), 2f)
        for (i in 0 until 28) {
            val x = (i * 0.37f % 1f) * w
            val y = (((i * 0.618f) % 1f + 1f - t) % 1f) * horizon
            drawCircle(if (i % 3 == 0) Neon.Magenta else Neon.Cyan, radius = 2f + (i % 3) * 1.5f, center = Offset(x, y), alpha = 0.8f)
        }
    }
}
