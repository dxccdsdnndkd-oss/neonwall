package com.neonwall.app.wallpaper

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.exp
import kotlin.math.hypot

/**
 * Game rotation vector asosida -1..1 oralig'ida "qiyshayish" (tilt) beradi.
 *
 * Matritsa: getRotationMatrixFromVector() row-major R (device -> world). 3-qator (R[6], R[7], R[8]) —
 * dunyo "yuqori" o'qining qurilma koordinatalaridagi ko'rinishi:
 *   R[6] ~ chap-o'ng qiyshayish, R[7] ~ telefon tikligi, R[8] ~ ekran osmonga qarashi.
 * Euler burchaklari (getOrientation) ishlatilmaydi: tik tutilganda gimbal lock bor.
 *
 * Sensor ~50 Hz da keladi, ekran esa 120-144 Hz da chiziladi. Shuning uchun sensor faqat MAQSAD qiymatni
 * yozadi, silliqlash esa har kadrda [update] ichida bajariladi (aks holda parallax "zinapoya" bo'lib seziladi).
 *
 * Ishora (qaysi tomonga siljishi) — dizayn tanlovi; qurilmada sinalmagan. Teskari bo'lsa
 * NeonWallpaperService.drawFrame ichida `-sensor.x` ishorasini almashtiring.
 */
class ParallaxSensor(context: Context) : SensorEventListener {
    private val manager = context.applicationContext.getSystemService(SensorManager::class.java)
    private val sensor: Sensor? = manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
        ?: manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

    /** Kadr bo'yicha silliqlangan qiymatlar (-1..1). */
    var x = 0f
        private set
    var y = 0f
        private set

    private val matrix = FloatArray(9)
    private var centerX = 0f
    private var centerY = 0f
    private var targetX = 0f
    private var targetY = 0f
    private var calibrated = false
    private var active = false

    fun start() {
        if (active || sensor == null) return
        active = true
        manager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        if (!active) return
        active = false
        manager.unregisterListener(this)
        calibrated = false   // keyingi start'da qayta kalibrlanadi
        x = 0f; y = 0f; targetX = 0f; targetY = 0f
    }

    /** Har kadrda chaqiriladi: maqsad sari eksponensial silliqlash (kadr chastotasiga bog'liq emas). */
    fun update(dt: Float) {
        if (!active) return
        val a = 1f - exp(-dt * FOLLOW_RATE)
        x += (targetX - x) * a
        y += (targetY - y) * a
    }

    override fun onSensorChanged(event: SensorEvent) {
        // Ba'zi qurilmalar ROTATION_VECTOR'da 5 ta qiymat beradi; getRotationMatrixFromVector buni qabul qiladi.
        SensorManager.getRotationMatrixFromVector(matrix, event.values)
        val tiltX = asin(matrix[6].coerceIn(-1f, 1f))                 // chap-o'ng
        val tiltY = atan2(matrix[7], hypot(matrix[6], matrix[8]))      // oldinga-orqaga
        if (!calibrated) {
            centerX = tiltX
            centerY = tiltY
            calibrated = true
        }
        centerX += (tiltX - centerX) * RECENTER
        centerY += (tiltY - centerY) * RECENTER
        targetX = ((tiltX - centerX) / MAX_ANGLE).coerceIn(-1f, 1f)
        targetY = ((tiltY - centerY) / MAX_ANGLE).coerceIn(-1f, 1f)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private companion object {
        const val MAX_ANGLE = 0.35f   // ~20°
        const val RECENTER = 0.004f   // har sensor hodisasida markazga sekin intilish (~5 s)
        const val FOLLOW_RATE = 14f   // 1/s: kadrlar orasidagi silliqlash tezligi
    }
}
