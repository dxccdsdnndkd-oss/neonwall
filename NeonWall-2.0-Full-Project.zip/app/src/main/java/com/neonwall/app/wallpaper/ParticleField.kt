package com.neonwall.app.wallpaper

import android.graphics.Canvas
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/**
 * Zarrachalar tizimi. Struct-of-arrays: obyekt yaratmaslik => GC pauza yo'q => 120 Hz da ham silliq.
 * `depth` (0.25..1) — parallax va yorqinlik koeffitsienti: uzoqdagilar xira va kam siljiydi.
 */
class ParticleField(private val capacity: Int) {
    private val x = FloatArray(capacity)
    private val y = FloatArray(capacity)
    private val vx = FloatArray(capacity)
    private val vy = FloatArray(capacity)
    private val depth = FloatArray(capacity)
    private val size = FloatArray(capacity)
    private val phase = FloatArray(capacity)
    private var width = 0f
    private var height = 0f

    var activeCount: Int = capacity

    fun resize(w: Float, h: Float) {
        width = w
        height = h
        for (i in 0 until capacity) spawn(i, anywhere = true)
    }

    private fun spawn(i: Int, anywhere: Boolean) {
        x[i] = Random.nextFloat() * width * 1.4f - width * 0.2f   // ekrandan kengroq (parallax uchun)
        y[i] = if (anywhere) Random.nextFloat() * height else height + 20f
        vx[i] = 0f
        vy[i] = 0f
        depth[i] = 0.25f + Random.nextFloat() * 0.75f
        size[i] = 0.6f + Random.nextFloat() * 1.8f
        phase[i] = Random.nextFloat() * TWO_PI
    }

    fun update(dt: Float, energy: Float, time: Float) {
        val damping = exp(-2.2f * dt)
        for (i in 0 until activeCount) {
            val rise = (12f + 40f * depth[i]) * (1f + energy * 2.5f)       // musiqada tezroq ko'tariladi
            x[i] += (vx[i] + sin(time * 0.6f + phase[i]) * 6f * depth[i]) * dt
            y[i] += (vy[i] - rise) * dt
            vx[i] *= damping
            vy[i] *= damping
            if (y[i] < -30f) spawn(i, anywhere = false)
        }
    }

    /** Teginish: atrofdagi zarrachalarni itarib yuboradi. */
    fun push(cx: Float, cy: Float, radius: Float, strength: Float) {
        for (i in 0 until activeCount) {
            val dx = x[i] - cx
            val dy = y[i] - cy
            val d = hypot(dx, dy)
            if (d < radius && d > 1f) {
                val f = (1f - d / radius) * strength
                vx[i] += dx / d * f
                vy[i] += dy / d * f
            }
        }
    }

    fun draw(
        canvas: Canvas, sprite: GlowSprite, primary: TintedPaint, secondary: TintedPaint,
        offX: Float, offY: Float, time: Float, alphaScale: Float, density: Float,
    ) {
        for (i in 0 until activeCount) {
            val twinkle = 0.65f + 0.35f * sin(time * 2.1f + phase[i])
            val tinted = if (i % 3 == 0) secondary else primary
            tinted.paint.alpha = (255f * depth[i] * twinkle * alphaScale).toInt().coerceIn(0, 255)
            sprite.draw(
                canvas,
                x[i] + offX * depth[i],
                y[i] + offY * depth[i],
                size[i] * depth[i] * 4f * density,
                tinted.paint,
            )
        }
    }

    private companion object { const val TWO_PI = 6.2831855f }
}
