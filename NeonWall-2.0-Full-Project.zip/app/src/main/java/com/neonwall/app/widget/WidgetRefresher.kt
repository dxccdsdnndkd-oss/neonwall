package com.neonwall.app.widget

import android.content.Context
import android.os.SystemClock
import androidx.glance.appwidget.updateAll
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.neonwall.app.data.WeatherRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

/**
 * Vidjetlarni yangilash.
 * Android vidjetlarni tez-tez yangilashga ruxsat bermaydi (updatePeriodMillis >= 30 daq, WorkManager >= 15 daq).
 * Hiyla: live wallpaper jarayoni uy ekrani ko'ringan zahoti [refreshIfStale] ni chaqiradi,
 * shuning uchun System Monitor foydalanuvchi qaraganda deyarli "jonli" bo'ladi.
 */
object WidgetRefresher {
    private const val MIN_INTERVAL_MS = 20_000L
    @Volatile private var last = 0L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    fun refreshIfStale(context: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - last < MIN_INTERVAL_MS) return
        last = now
        val app = context.applicationContext
        scope.launch { updateAll(app) }
    }

    suspend fun updateAll(context: Context) {
        runCatching { ClockWeatherWidget().updateAll(context) }
        runCatching { SystemMonitorWidget().updateAll(context) }
        runCatching { MusicWidget().updateAll(context) }
    }
}

/** Har 30 daqiqada ob-havoni yangilaydi va vidjetlarni qayta chizadi. */
class RefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        WeatherRepository(applicationContext).refresh()
        WidgetRefresher.updateAll(applicationContext)
        return Result.success()
    }

    companion object {
        private const val UNIQUE_NAME = "neonwall_refresh"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<RefreshWorker>(30, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }

        fun runNow(context: Context) {
            WorkManager.getInstance(context).enqueue(OneTimeWorkRequestBuilder<RefreshWorker>().build())
        }
    }
}
